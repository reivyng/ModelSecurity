﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.DTOautogestion
{
    public class AprendizProgramDto
    {
        public int Id { get; set; }
        public int ProgramId { get; set; }
        public int AprendizId { get; set; }
    }
}
